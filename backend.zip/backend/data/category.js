const category=[
    {
        name:"dashain dhamaka"
    },
    {
        name:"11:11"
    },
    {
        name:"black friday"
    },
]

export default category;