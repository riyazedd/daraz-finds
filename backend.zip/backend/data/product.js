const products=[
    {
        product_link:'https://www.daraz.com.np/products/multicolor-never-ending-pencil-i155520753-s1119882378.html?laz_trackid=2:mm_150202953_425939645_4180939145:clkgg5r031ik2j342ujlok&mkttid=clkgg5r031ik2j342ujlok',
        
        
    },
    {
        product_link:"https://www.daraz.com.np/products/21pcs-tulip-nightlight-handmade-diy-material-cube-tulip-mirror-bedroom-decor-atmosphere-lamp-valentines-day-birthday-gift-taotai-i149865329-s1191830187.html?laz_trackid=2:mm_150202953_425939645_4180939145:clkgk22sp1ik3pfgs43no8&mkttid=clkgk22sp1ik3pfgs43no8",
        
        
    },
    {
        product_link:'https://www.daraz.com.np/products/redragon-kumara-k552-rgb-led-rainbow-backlit-wired-mechanical-gaming-keyboard-i133170974-s1052500777.html?laz_trackid=2:mm_150202953_425939645_4180939145:clkgg5r031ik3pje4j25r3&mkttid=clkgg5r031ik3pje4j25r3',
        
        
    },
    {
        product_link:'https://www.daraz.com.np/products/25th-sep-deal-ultima-boom-141-anc-earbuds-30-db-45hrs-playtime-game-mode-40ms-ipx5-water-resistant-13-mm-drivers-for-deep-bass-wireless-earbuds-i128436556-s1035911944.html?laz_trackid=2:mm_150202953_425939645_4180939145:clkgk22sp1ik3pm3p33qiq&mkttid=clkgk22sp1ik3pm3p33qiq',
        
        
    },
    {
        product_link:'https://www.daraz.com.np/products/ichhya-store-temparature-thermos-i177953747-s1202064915.html?laz_trackid=2:mm_150202953_425939645_4180939145:clkgg5r031ik3pntgh27qn&mkttid=clkgg5r031ik3pntgh27qn',
  
        
    },
    {
        product_link:'https://www.daraz.com.np/products/spray-function-microfiber-mop-i100470873-s1020780131.html?laz_trackid=2:mm_150202953_425939645_4180939145:clkgk2dck1ik3pperi2qp9&mkttid=clkgk2dck1ik3pperi2qp9',
        
        
    },
]

export default products;